public class Administrador extends Usuario {
    public Administrador(int id, String nombre, String correo) {
        super(id, nombre, correo);
    }

    @Override
    public String getRol() {
        return "Administrador";
    }
}
