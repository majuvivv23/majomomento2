public class Cliente extends Usuario {
    public Cliente(int id, String nombre, String correo) {
        super(id, nombre, correo);
    }

    @Override
    public String getRol() {
        return "Cliente";
    }
}
