public class Proveedor {
    private int documento;
    private String nombre;
    private String telefono;

    public Proveedor(int documento, String nombre, String telefono) {
        this.documento = documento;
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public int getDocumento() {
        return documento;
    }

    public void mostrarInformacion() {
        System.out.println("Documento: " + documento);
        System.out.println("Proveedor: " + nombre);
        System.out.println("Telefono: " + telefono);
    }
}
