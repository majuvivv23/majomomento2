import java.util.ArrayList;

public class RegistroTienda implements IOperaciones<Producto> {
    private ArrayList<Producto> productos = new ArrayList<>();
    private ArrayList<Proveedor> proveedores = new ArrayList<>();

    @Override
    public void guardar(Producto producto) {
        if (buscar(producto.getCodigo()) == null) {
            productos.add(producto);
            System.out.println("Producto guardado correctamente.");
        } else {
            System.out.println("Ya existe un producto con ese codigo.");
        }
    }

    public void listarProductos() {
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }

        for (Producto producto : productos) {
            producto.mostrarInformacion();
            System.out.println("--------------------");
        }
    }

    @Override
    public Producto buscar(int codigo) {
        for (Producto producto : productos) {
            if (producto.getCodigo() == codigo) {
                return producto;
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(int codigo) {
        Producto producto = buscar(codigo);
        if (producto != null) {
            productos.remove(producto);
            return true;
        }
        return false;
    }

    public void actualizarProducto(int codigo, String nombre, double precio, int cantidad) {
        Producto producto = buscar(codigo);
        if (producto == null) {
            System.out.println("Producto no encontrado.");
            return;
        }

        producto.setNombre(nombre);
        producto.setPrecio(precio);
        producto.setCantidad(cantidad);
        System.out.println("Producto actualizado correctamente.");
    }

    public void guardarProveedor(Proveedor proveedor) {
        proveedores.add(proveedor);
    }

    public void listarProveedores() {
        if (proveedores.isEmpty()) {
            System.out.println("No hay proveedores registrados.");
            return;
        }
        for (Proveedor proveedor : proveedores) {
            proveedor.mostrarInformacion();
            System.out.println("--------------------");
        }
    }
}
