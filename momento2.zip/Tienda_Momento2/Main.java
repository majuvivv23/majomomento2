import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RegistroTienda registro = new RegistroTienda();

        
        registro.guardar(new Producto(1, "Pan", 3000, 20));
        registro.guardar(new Producto(2, "Leche", 4000, 15));
        registro.guardar(new Producto(3, "Huevos", 15000, 10));
        registro.guardarProveedor(new Proveedor(123456, "Distribuidora Bimbo", "3001234567"));
        registro.guardarProveedor(new Proveedor(789012, "Productos Panes", "3107654321"));

        
        Usuario usuario1 = new Administrador(1, "Ana", "ana@correo.com");
        Usuario usuario2 = new Cliente(2, "Carlos", "carlos@correo.com");
        System.out.println("Ejemplo de polimorfismo");
        usuario1.mostrarInformacion();
        usuario2.mostrarInformacion();

        int opcion;
        do {
            System.out.println("\\n===== MENU TIENDA =====");
            System.out.println("1. Crear producto");
            System.out.println("2. Listar productos");
            System.out.println("3. Buscar producto");
            System.out.println("4. Actualizar producto");
            System.out.println("5. Eliminar producto");
            System.out.println("6. Listar proveedores");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");

            while (!sc.hasNextInt()) {
                System.out.print("Digite un numero: ");
                sc.next();
            }
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Codigo: ");
                    int codigo = leerEntero(sc);
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Precio: ");
                    double precio = leerDouble(sc);
                    System.out.print("Cantidad: ");
                    int cantidad = leerEntero(sc);

                    if (codigo > 0 && precio >= 0 && cantidad >= 0 && !nombre.trim().isEmpty()) {
                        registro.guardar(new Producto(codigo, nombre, precio, cantidad));
                    } else {
                        System.out.println("Datos invalidos. Revise codigo, nombre, precio y cantidad.");
                    }
                    break;

                case 2:
                    registro.listarProductos();
                    break;

                case 3:
                    System.out.print("Codigo del producto: ");
                    Producto encontrado = registro.buscar(leerEntero(sc));
                    if (encontrado != null) {
                        encontrado.mostrarInformacion();
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 4:
                    System.out.print("Codigo del producto que desea actualizar: ");
                    int codigoActualizar = leerEntero(sc);
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = sc.nextLine();
                    System.out.print("Nuevo precio: ");
                    double nuevoPrecio = leerDouble(sc);
                    System.out.print("Nueva cantidad: ");
                    int nuevaCantidad = leerEntero(sc);
                    if (nuevoPrecio >= 0 && nuevaCantidad >= 0 && !nuevoNombre.trim().isEmpty()) {
                        registro.actualizarProducto(codigoActualizar, nuevoNombre, nuevoPrecio, nuevaCantidad);
                    } else {
                        System.out.println("Datos invalidos.");
                    }
                    break;

                case 5:
                    System.out.print("Codigo del producto que desea eliminar: ");
                    if (registro.eliminar(leerEntero(sc))) {
                        System.out.println("Producto eliminado.");
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 6:
                    registro.listarProveedores();
                    break;

                case 0:
                    System.out.println("Programa finalizado.");
                    break;

                default:
                    System.out.println("Opcion no valida.");
            }
        } while (opcion != 0);

        sc.close();
    }

    private static int leerEntero(Scanner sc) {
        while (!sc.hasNextInt()) {
            System.out.print("Digite un numero entero: ");
            sc.next();
        }
        int numero = sc.nextInt();
        sc.nextLine();
        return numero;
    }

    private static double leerDouble(Scanner sc) {
        while (!sc.hasNextDouble()) {
            System.out.print("Digite un numero valido: ");
            sc.next();
        }
        double numero = sc.nextDouble();
        sc.nextLine();
        return numero;
    }
}
